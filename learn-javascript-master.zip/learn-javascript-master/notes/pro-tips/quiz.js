// Remove Duplicates!
const array = ['🐶', '🐱', '🐈', '🐶', '🦮', '🐱'];

console.log(array);

console.log([...new Set(array)]);
